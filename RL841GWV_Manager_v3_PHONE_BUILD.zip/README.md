# RL841GWV Manager v3 — phone build package

This is the RL841GWV-DGB Manager WebView app project.

## App
- Default router: 192.168.1.1
- Home: /cgi-bin/index2.asp
- Settings: /cgi-bin/content.asp
- XPON/RMS: /cgi-bin/register.asp
- Uses the router's existing WebUI; no undocumented CGI/API commands are invented.

## Build on a phone
The included GitHub Actions workflow builds the debug APK in the cloud, so Android SDK/Gradle do not need to be installed on the phone.

Workflow file: `.github/workflows/build-apk.yml`

After the workflow finishes, download the `RL841GWV-debug` artifact from the GitHub Actions run. The APK inside is `app-debug.apk`.
