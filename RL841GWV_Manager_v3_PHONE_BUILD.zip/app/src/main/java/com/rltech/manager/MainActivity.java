package com.rltech.manager;
import android.app.*; import android.os.*; import android.graphics.Bitmap; import android.webkit.*; import android.widget.*; import android.view.*;
public class MainActivity extends Activity {
 EditText ip; TextView status; WebView web;
 String base(){String h=ip.getText().toString().trim(); if(h.startsWith("http://")||h.startsWith("https://")) return h; return "http://"+h;}
 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);
  ip=findViewById(R.id.ip); status=findViewById(R.id.status); web=findViewById(R.id.web);
  WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setBuiltInZoomControls(false); s.setLoadWithOverviewMode(true); s.setUseWideViewPort(true);
  web.setWebViewClient(new WebViewClient(){public void onPageStarted(WebView v,String u,Bitmap x){status.setText("Loading: "+u);} public void onPageFinished(WebView v,String u){status.setText("Connected: "+u);}});
  findViewById(R.id.go).setOnClickListener(v->load("/cgi-bin/index2.asp"));
  findViewById(R.id.home).setOnClickListener(v->load("/cgi-bin/index2.asp"));
  findViewById(R.id.register).setOnClickListener(v->load("/cgi-bin/register.asp"));
  findViewById(R.id.content).setOnClickListener(v->load("/cgi-bin/content.asp"));
  load("/cgi-bin/index2.asp");
 }
 void load(String p){web.loadUrl(base()+p);}
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}